<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "fredico";

$koneksi  = mysqli_connect ($host, $user, $pass, $db);
?>