<?php
include "connect.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>

    <header style="text-align: center;">
        <h2 class="logo"><span>F</span>redico Website</h2>
    </header>
    

    <table class="content-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>NIM</th>
            <th>Jurusan</th>
            <th>Email</th>
            <th>Password</th>
            <th>Jenis Kelamin</th>
            <th>Tanggal Lahir</th>
            <th>Alamat</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $sql2 = "select * from data order by 'id' desc";
          $q2 = mysqli_query($koneksi,$sql2);
          while($r2 = mysqli_fetch_array ($q2)){
            $nama = $r2['nama'];
            $nim = $r2['nim'];
            $jurusan = $r2['jurusan'];
            $email = $r2['email'];
            $password = $r2['password'];
            $jeniskelamin = $r2['jeniskelamin'];
            $lahir = $r2['lahir'];
            $alamat = $r2['alamat'];
          ?>
          <tr>
           <th scope="row"> <?php echo $nama ?> </th>
           <th scope="row"> <?php echo $nim ?> </th>
           <th scope="row"> <?php echo $jurusan ?> </th>
           <th scope="row"> <?php echo $email ?> </th>
           <th scope="row"> <?php echo $password ?> </th>
           <th scope="row"> <?php echo $jeniskelamin ?> </th>
           <th scope="row"> <?php echo $lahir ?> </th>
           <th scope="row"> <?php echo $alamat ?> </th>
          </tr>
          <?php
          }
          ?>
        </tbody>
      </table>

      <input type="checkbox" id="check">
    <label for="check">
      <i class="fas fa-bars" id="btn"></i>
      <i class="fas fa-times" id="cancel"></i>
    </label>
    <div class="sidebar">
    <header>Menu</header>
    <ul>
     <li><a href="index.html"><i class="fas fa-qrcode"></i>Home</a></li>
     <li><a href="form.php"><i class="fas fa-link"></i>Form</a></li>
    </ul>
   </div>

</body>

<footer style="text-align: center; position: relative; background-color: #07074d; color: #ffffff; height: 50px; bottom: -460px; width: 100%;"
    <p>Copyright Fredico</p>
  </footer>

</html>