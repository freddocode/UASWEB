-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2023 at 03:39 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fredico`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `nama` binary(30) NOT NULL,
  `nim` char(6) NOT NULL,
  `jurusan` varchar(30) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` int(8) NOT NULL,
  `jeniskelamin` varchar(10) NOT NULL,
  `lahir` varchar(8) NOT NULL,
  `alamat` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`nama`, `nim`, `jurusan`, `email`, `password`, `jeniskelamin`, `lahir`, `alamat`) VALUES
(0x667265640000000000000000000000000000000000000000000000000000, '123', 'rpl', 'fredico@gmail.com', 123, 'pria', '23/06/20', 'nagoya'),
(0x667265640000000000000000000000000000000000000000000000000000, '123', 'rpl', 'fredico@gmail.com', 123, 'pria', '23/06/20', 'nagoya'),
(0x667265640000000000000000000000000000000000000000000000000000, '1234', 'rpl', 'fred@gmail.com', 456, 'pria', '12/02/20', 'nagoya'),
(0x667265640000000000000000000000000000000000000000000000000000, '123', 'rpl', 'mifojan540@picvw.com', 123, 'pria', '30/01/20', 'nagoya'),
(0x667265640000000000000000000000000000000000000000000000000000, '123', 'rpl', 'mifojan540@picvw.com', 123, 'pria', '30/01/20', 'nagoya');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
